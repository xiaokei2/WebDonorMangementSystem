(function() {
  $(function() {
    return $('input[data-role=money]').autoNumeric('init');
  });

}).call(this);
